## Headout Clone by ~ lastnamearya
Currently main route(home) and New York route is active.


[<img width="1426" alt="Screenshot 2020-07-19 at 7 25 30 AM" src="https://user-images.githubusercontent.com/6664187/87865323-6fb81f80-c991-11ea-98fd-899b72f17538.png">](https://lastnamearya-headout.netlify.app/)

[<img width="1423" alt="Screenshot 2020-07-19 at 7 26 17 AM" src="https://user-images.githubusercontent.com/6664187/87865325-76df2d80-c991-11ea-863b-3faf00d1dd53.png">](https://lastnamearya-headout.netlify.app/)


[<img width="1427" alt="Screenshot 2020-07-19 at 7 26 32 AM" src="https://user-images.githubusercontent.com/6664187/87865327-78105a80-c991-11ea-87d1-ecd05e551ddb.png">
](https://lastnamearya-headout.netlify.app/)

-------------------------------------------------------


[![Twitter Follow](https://img.shields.io/twitter/follow/lastnamearya.svg?style=social&label=Follow%20%40lastnamearya)](https://twitter.com/lastnamearya)

:house:&nbsp; [lastnamearya.github.io](https://lastnamearya.github.io)

:email:&nbsp; arya.jigyasu6815@gmail.com


